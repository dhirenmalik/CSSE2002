https://chatgpt.com/share/03d0612c-afb7-4cc7-b670-ba885aff62fb
used ai to style the code accordingly.