package farm.sales;

import farm.inventory.product.Product;
import farm.inventory.product.data.Barcode;
import farm.sales.transaction.Transaction;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Manages and stores the history of all transactions made within the farm system.
 * Provides methods to analyze and retrieve data about past transactions.
 */
public class TransactionHistory {
    private List<Transaction> transactions;

    /**
     * Constructs a new TransactionHistory with an empty list of transactions.
     */
    public TransactionHistory() {
        this.transactions = new ArrayList<>();
    }

    /**
     * Records a transaction if it is finalized.
     *
     * @param transaction the transaction to record.
     * @throws IllegalArgumentException if the transaction is not finalized.
     */
    public void recordTransaction(Transaction transaction) {
        if (transaction.isFinalised()) {
            transactions.add(transaction);
        } else {
            throw new IllegalArgumentException("Only finalised transactions can be recorded.");
        }
    }

    /**
     * Retrieves the last recorded transaction.
     *
     * @return the last transaction, or null if no transactions are recorded.
     */
    public Transaction getLastTransaction() {
        if (transactions.isEmpty()) {
            return null;
        }
        return transactions.get(transactions.size() - 1);
    }

    /**
     * Calculates the total earnings from all recorded transactions.
     *
     * @return the gross earnings from all transactions.
     */
    public int getGrossEarnings() {
        return transactions.stream()
                .mapToInt(Transaction::getTotal)
                .sum();
    }

    /**
     * Calculates the total earnings from the sale of a specific product type.
     *
     * @param type the barcode of the product type.
     * @return the gross earnings from the specified product type.
     */
    public int getGrossEarnings(Barcode type) {
        return transactions.stream()
                .flatMap(t -> t.getPurchases().stream())
                .filter(p -> p.getBarcode() == type)
                .mapToInt(Product::getBasePrice)
                .sum();
    }

    /**
     * Returns the total number of transactions made.
     *
     * @return the number of transactions recorded.
     */
    public int getTotalTransactionsMade() {
        return transactions.size();
    }

    /**
     * Returns the total number of products sold across all transactions.
     *
     * @return the total number of products sold.
     */
    public int getTotalProductsSold() {
        return transactions.stream()
                .mapToInt(t -> t.getPurchases().size())
                .sum();
    }

    /**
     * Returns the total number of a specific product type sold across all transactions.
     *
     * @param type the barcode of the product type.
     * @return the total number of the specified product sold.
     */
    public int getTotalProductsSold(Barcode type) {
        return (int) transactions.stream()
                .flatMap(t -> t.getPurchases().stream())
                .filter(p -> p.getBarcode() == type)
                .count();
    }

    /**
     * Retrieves the highest-grossing transaction based on the total amount.
     *
     * @return the transaction with the highest total, or null if no transactions exist.
     */
    public Transaction getHighestGrossingTransaction() {
        return transactions.stream()
                .max(Comparator.comparingInt(Transaction::getTotal))
                .orElse(null);
    }

    /**
     * Identifies the most popular product based on the total number of units sold.
     *
     * @return the barcode of the most popular product, or null if no products have been sold.
     */
    public Barcode getMostPopularProduct() {
        Map<Barcode, Long> productCounts = transactions.stream()
                .flatMap(t -> t.getPurchases().stream())
                .collect(Collectors.groupingBy(Product::getBarcode, Collectors.counting()));

        return productCounts.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);
    }

    /**
     * Calculates the average amount spent per transaction.
     *
     * @return the average spend per visit, or 0.0 if no transactions exist.
     */
    public double getAverageSpendPerVisit() {
        if (transactions.isEmpty()) {
            return 0.0d;
        }
        double totalSpend = getGrossEarnings();
        return totalSpend / getTotalTransactionsMade();
    }

    /**
     * Estimates the average discount applied to a specific product type across all transactions.
     *
     * @param type the barcode of the product type.
     * @return the average discount percentage, or 0.0 if the product has not been sold.
     */
    public double getAverageProductDiscount(Barcode type) {
        List<Product> products = transactions.stream()
                .flatMap(t -> t.getPurchases().stream())
                .filter(p -> p.getBarcode() == type)
                .collect(Collectors.toList());

        if (products.isEmpty()) {
            return 0.0d;
        }

        double totalBasePrice = products.stream().mapToDouble(Product::getBasePrice).sum();
        double totalActualPrice = transactions.stream()
                .filter(t -> t.getPurchases().stream().anyMatch(p -> p.getBarcode() == type))
                .mapToDouble(Transaction::getTotal)
                .sum();

        double totalDiscount = totalBasePrice - totalActualPrice;
        return totalDiscount / products.size();
    }
}
