package farm.sales;

import farm.inventory.product.Product;
import farm.core.FailedTransactionException;
import farm.sales.transaction.Transaction;

/**
 * Manages the current transaction within the farm system, allowing
 * for the registration, ongoing processing, and finalization of transactions.
 */
public class TransactionManager {
    private Transaction currentTransaction;

    /**
     * Initializes the TransactionManager with no ongoing transaction.
     */
    public TransactionManager() {
        this.currentTransaction = null;
    }

    /**
     * Checks if there is an ongoing transaction.
     *
     * @return true if there is a current ongoing transaction, false otherwise.
     */
    public boolean hasOngoingTransaction() {
        return currentTransaction != null;
    }

    /**
     * Sets the current transaction as the ongoing transaction.
     *
     * @param transaction the transaction to set as ongoing.
     * @throws FailedTransactionException if a transaction is already in progress.
     */
    public void setOngoingTransaction(Transaction transaction) throws FailedTransactionException {
        if (hasOngoingTransaction()) {
            throw new FailedTransactionException("A transaction is already in progress.");
        }
        this.currentTransaction = transaction;
    }

    /**
     * Registers a pending purchase within the ongoing transaction.
     *
     * @param product the product to add to the current transaction.
     * @throws FailedTransactionException if there is no ongoing transaction or if the transaction is already finalized.
     */
    public void registerPendingPurchase(Product product) throws FailedTransactionException {
        if (!hasOngoingTransaction()) {
            throw new FailedTransactionException("No ongoing transaction to register purchase.");
        }
        if (currentTransaction.isFinalised()) {
            throw new FailedTransactionException("Current transaction has already been finalised.");
        }
        currentTransaction.getAssociatedCustomer().getCart().addProduct(product);
    }

    /**
     * Finalizes and closes the current transaction, returning it for further processing.
     *
     * @return the finalized transaction.
     * @throws FailedTransactionException if there is no ongoing transaction to close.
     */
    public Transaction closeCurrentTransaction() throws FailedTransactionException {
        if (!hasOngoingTransaction()) {
            throw new FailedTransactionException("No ongoing transaction to close.");
        }

        Transaction finalisedTransaction = currentTransaction;
        finalisedTransaction.finalise();
        currentTransaction = null;

        return finalisedTransaction;
    }
}
