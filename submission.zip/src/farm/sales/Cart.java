package farm.sales;

import farm.inventory.product.Product;

import java.util.ArrayList;
import java.util.List;

/**
 * A shopping cart that stores the customer's products until they check out.
 * Products are maintained in the order they are added.
 */
public class Cart {

    private List<Product> products;

    /**
     * Constructs a new, empty shopping cart.
     */
    public Cart() {
        this.products = new ArrayList<>();
    }

    /**
     * Adds a given product to the shopping cart.
     *
     * @param product the product to add to the cart
     */
    public void addProduct(Product product) {
        if (product != null) {
            this.products.add(product);
        }
    }

    /**
     * Retrieves all products in the cart in the order they were added.
     *
     * @return a list of all products in the cart
     */
    public List<Product> getContents() {
        return new ArrayList<>(this.products);
    }

    /**
     * Empties out the shopping cart.
     */
    public void setEmpty() {
        this.products.clear();
    }

    /**
     * Checks if the cart is empty.
     *
     * @return true if the cart is empty, otherwise false
     */
    public boolean isEmpty() {
        return this.products.isEmpty();
    }
}
