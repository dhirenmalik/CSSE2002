package farm.sales.transaction;

import farm.customer.Customer;
import farm.inventory.product.Product;
import farm.inventory.product.data.Barcode;
import farm.sales.ReceiptPrinter;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Represents a special sale transaction that includes discounts for specific products.
 * Extends {@link CategorisedTransaction} to categorize products and apply discounts.
 */
public class SpecialSaleTransaction extends CategorisedTransaction {
    private Map<Barcode, Integer> discounts;

    /**
     * Constructs a SpecialSaleTransaction for a customer with no initial discounts.
     *
     * @param customer the customer associated with this transaction.
     */
    public SpecialSaleTransaction(Customer customer) {
        super(customer);
        this.discounts = new HashMap<>();
    }

    /**
     * Constructs a SpecialSaleTransaction for a customer with specified discounts.
     *
     * @param customer  the customer associated with this transaction.
     * @param discounts a map of product barcodes to discount percentages.
     */
    public SpecialSaleTransaction(Customer customer, Map<Barcode, Integer> discounts) {
        super(customer);
        this.discounts = new HashMap<>(discounts);
    }

    /**
     * Gets the purchase subtotal for a specific product type after applying the discount.
     *
     * @param type the barcode of the product type.
     * @return the discounted subtotal for the product type.
     */
    @Override
    public int getPurchaseSubtotal(Barcode type) {
        int subtotal = super.getPurchaseSubtotal(type);
        int discountPercentage = getDiscountAmount(type);
        return subtotal - (subtotal * discountPercentage / 100);
    }

    /**
     * Gets the discount percentage for a specific product type.
     *
     * @param type the barcode of the product type.
     * @return the discount percentage, or 0 if no discount is applied.
     */
    public int getDiscountAmount(Barcode type) {
        return discounts.getOrDefault(type, 0);
    }

    /**
     * Calculates the total cost of all purchased products after applying discounts.
     *
     * @return the total cost after discounts.
     */
    @Override
    public int getTotal() {
        return getPurchasedTypes().stream()
                .mapToInt(this::getPurchaseSubtotal)
                .sum();
    }

    /**
     * Calculates the total amount saved due to discounts.
     *
     * @return the total amount saved.
     */
    public int getTotalSaved() {
        int totalWithoutDiscount = getPurchasedTypes().stream()
                .mapToInt(super::getPurchaseSubtotal)
                .sum();
        return totalWithoutDiscount - getTotal();
    }

    /**
     * Returns a string representation of the transaction, including customer information, status, purchased products, and discounts.
     *
     * @return a string describing the transaction.
     */
    @Override
    public String toString() {
        String status = isFinalised() ? "Finalised" : "Active";
        String customerString = getAssociatedCustomer().toString().replaceFirst("Name: ", "");
        return String.format("Transaction {Customer: %s, Status: %s, Associated Products: %s,"
                        + " Discounts: %s}",
                customerString, status, getPurchases(), discounts);
    }

    /**
     * Generates a receipt for the transaction, including details of purchased products, discounts, and the total amount.
     *
     * @return a formatted receipt string.
     */
    @Override
    public String getReceipt() {
        if (!isFinalised()) {
            return ReceiptPrinter.createActiveReceipt();
        }

        List<String> headings = List.of("Item", "Qty", "Price (ea.)", "Subtotal");
        List<List<String>> entries = new ArrayList<>();

        for (Barcode type : Barcode.values()) {
            int quantity = getPurchaseQuantity(type);
            if (quantity > 0) {
                List<String> entry = new ArrayList<>();
                entry.add(type.getDisplayName());
                entry.add(String.valueOf(quantity));
                entry.add(formatPrice(getPurchasesByType().get(type).get(0).getBasePrice()));
                entry.add(formatPrice(getPurchaseSubtotal(type)));

                int discountAmount = getDiscountAmount(type);
                if (discountAmount > 0) {
                    entry.add(String.format("Discount applied! %d%% off %s", discountAmount,
                            type.getDisplayName()));
                }

                entries.add(entry);
            }
        }

        String total = formatPrice(getTotal());
        String customerName = getAssociatedCustomer().getName();
        int totalSaved = getTotalSaved();

        if (totalSaved > 0) {
            return ReceiptPrinter.createReceipt(headings, entries, total, customerName,
                    formatPrice(totalSaved));
        } else {
            return ReceiptPrinter.createReceipt(headings, entries, total, customerName);
        }
    }

    /**
     * Formats the price from cents to a dollar string format.
     *
     * @param cents the price in cents.
     * @return the formatted price as a string.
     */
    private String formatPrice(int cents) {
        return String.format("$%.2f", cents / 100.0);
    }
}
