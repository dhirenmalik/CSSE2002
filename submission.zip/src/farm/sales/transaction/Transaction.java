package farm.sales.transaction;

import farm.customer.Customer;
import farm.inventory.product.Product;
import farm.sales.ReceiptPrinter;

import java.util.ArrayList;
import java.util.List;

/**
 * Manages a transaction that tracks items purchased by a customer.
 * A transaction can be in one of two states: Active or Finalised.
 * An active transaction allows modifications, while a finalised transaction represents a
 * completed sale.
 */
public class Transaction {

    private Customer associatedCustomer;
    private boolean finalised;
    private List<Product> purchases;

    /**
     * Constructs a new transaction for an associated customer.
     *
     * @param customer the customer initiating the transaction
     */
    public Transaction(Customer customer) {
        this.associatedCustomer = customer;
        this.finalised = false;
        this.purchases = new ArrayList<>();
    }

    /**
     * Retrieves the customer associated with this transaction.
     *
     * @return the associated customer
     */
    public Customer getAssociatedCustomer() {
        return associatedCustomer;
    }

    /**
     * Retrieves all products associated with this transaction.
     *
     * @return a list of products associated with the transaction
     */
    public List<Product> getPurchases() {
        if (finalised) {
            return new ArrayList<>(purchases);
        } else {
            return new ArrayList<>(associatedCustomer.getCart().getContents());
        }
    }

    /**
     * Calculates the total price of all current products in the transaction.
     *
     * @return the total price in cents
     */
    public int getTotal() {
        return getPurchases().stream()
                .mapToInt(Product::getBasePrice)
                .sum();
    }

    /**
     * Checks if the transaction is finalised.
     *
     * @return true if the transaction is finalised, otherwise false
     */
    public boolean isFinalised() {
        return finalised;
    }

    /**
     * Finalises the transaction, locking in the current purchases and clearing the customer's cart.
     */
    public void finalise() {
        if (!finalised) {
            this.purchases = new ArrayList<>(associatedCustomer.getCart().getContents());
            associatedCustomer.getCart().setEmpty();
            this.finalised = true;
        }
    }

    @Override
    public String toString() {
        String status = finalised ? "Finalised" : "Active";
        String customerString = associatedCustomer.toString().replaceFirst("Name: ", "");
        return String.format("Transaction {Customer: %s, Status: %s, Associated Products: %s}",
                customerString, status, getPurchases());
    }

    /**
     * Generates a formatted receipt for this transaction.
     *
     * @return the formatted receipt string
     */
    public String getReceipt() {
        if (!finalised) {
            return ReceiptPrinter.createActiveReceipt();
        }

        List<String> headings = List.of("Item", "Price");
        List<List<String>> entries = new ArrayList<>();

        for (Product product : purchases) {
            entries.add(List.of(
                    product.getDisplayName(),
                    formatPrice(product.getBasePrice())
            ));
        }

        String total = formatPrice(getTotal());
        String customerName = associatedCustomer.getName();

        return ReceiptPrinter.createReceipt(headings, entries, total, customerName);
    }

    /**
     * Formats a price from cents to a dollar string representation.
     *
     * @param cents the price in cents
     * @return the formatted price string
     */
    private String formatPrice(int cents) {
        return String.format("$%.2f", cents / 100.0);
    }
}
