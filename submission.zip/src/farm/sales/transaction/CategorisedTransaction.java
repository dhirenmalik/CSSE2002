package farm.sales.transaction;

import farm.customer.Customer;
import farm.inventory.product.Product;
import farm.inventory.product.data.Barcode;
import farm.sales.ReceiptPrinter;

import java.util.*;
import java.util.stream.Collectors;

/**
 * A transaction type that allows products to be categorised by their types.
 */
public class CategorisedTransaction extends Transaction {

    private Map<Barcode, List<Product>> purchasesByType;

    /**
     * Constructs a new categorised transaction for an associated customer.
     *
     * @param customer the customer who is starting the transaction
     */
    public CategorisedTransaction(Customer customer) {
        super(customer);
        this.purchasesByType = new HashMap<>();
    }

    @Override
    public void finalise() {
        if (!isFinalised()) {
            super.finalise();
            categorisePurchases();
        }
    }

    /**
     * Categorizes the purchases by their product types.
     */
    private void categorisePurchases() {
        purchasesByType = getPurchases().stream()
                .collect(Collectors.groupingBy(Product::getBarcode));
    }

    /**
     * Retrieves all unique product types of the purchases associated with the transaction.
     *
     * @return a set of all product types in the transaction
     */
    public Set<Barcode> getPurchasedTypes() {
        return new HashSet<>(getPurchasesByType().keySet());
    }

    /**
     * Retrieves all products associated with the transaction, grouped by their type.
     *
     * @return the products in the transaction, grouped by their type
     */
    public Map<Barcode, List<Product>> getPurchasesByType() {
        if (!isFinalised()) {
            return getPurchases().stream()
                    .collect(Collectors.groupingBy(Product::getBarcode));
        }
        return new HashMap<>(purchasesByType);
    }

    /**
     * Retrieves the number of products of a particular type associated with the transaction.
     *
     * @param type the product type
     * @return the number of products of the specified type
     */
    public int getPurchaseQuantity(Barcode type) {
        return getPurchasesByType().getOrDefault(type, Collections.emptyList()).size();
    }

    /**
     * Determines the total price for the provided product type within this transaction.
     *
     * @param type the product type
     * @return the total price for all instances of that product type
     */
    public int getPurchaseSubtotal(Barcode type) {
        return getPurchasesByType().getOrDefault(type, Collections.emptyList()).stream()
                .mapToInt(Product::getBasePrice)
                .sum();
    }

    @Override
    public String getReceipt() {
        if (!isFinalised()) {
            return ReceiptPrinter.createActiveReceipt();
        }

        List<String> headings = List.of("Item", "Qty", "Price (ea.)", "Subtotal");
        List<List<String>> entries = new ArrayList<>();

        for (Barcode type : Barcode.values()) {
            int quantity = getPurchaseQuantity(type);
            if (quantity > 0) {
                int pricePerItem = getPurchasesByType().get(type).get(0).getBasePrice();
                int subtotal = getPurchaseSubtotal(type);

                entries.add(List.of(
                        type.getDisplayName(),
                        String.valueOf(quantity),
                        formatPrice(pricePerItem),
                        formatPrice(subtotal)
                ));
            }
        }

        String total = formatPrice(getTotal());
        String customerName = getAssociatedCustomer().getName();

        return ReceiptPrinter.createReceipt(headings, entries, total, customerName);
    }

    /**
     * Formats the price from cents to a dollar string representation.
     *
     * @param cents the price in cents
     * @return the formatted price string
     */
    private String formatPrice(int cents) {
        return String.format("$%.2f", cents / 100.0);
    }
}
