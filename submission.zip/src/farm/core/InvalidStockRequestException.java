package farm.core;

import java.io.Serializable;

/**
 * Thrown if attempting to perform a stock operation with invalid parameters.
 * Component of Stage 2.
 */
public class InvalidStockRequestException extends Exception implements Serializable {

    /**
     * Construct an exception in response to an invalid stock request with no additional details.
     */
    public InvalidStockRequestException() {
        super();
    }

    /**
     * Construct an exception in response to an invalid stock request with a message describing the exception.
     *
     * @param message The description of the exception.
     */
    public InvalidStockRequestException(String message) {
        super(message);
    }
}