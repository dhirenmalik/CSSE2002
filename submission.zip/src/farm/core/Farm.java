package farm.core;

import farm.customer.AddressBook;
import farm.customer.Customer;
import farm.inventory.Inventory;
import farm.inventory.product.data.Barcode;
import farm.inventory.product.Product;
import farm.inventory.product.data.Quality;
import farm.sales.TransactionHistory;
import farm.sales.TransactionManager;
import farm.sales.transaction.Transaction;

import java.util.List;

/**
 * The Farm class serves as the core controller of the farm's operations,
 * managing inventory, customer information, and transaction processing.
 */
public class Farm {
    private Inventory inventory;
    private AddressBook addressBook;
    private TransactionManager transactionManager;
    private TransactionHistory transactionHistory;

    /**
     * Constructs a new Farm instance with the provided inventory and address book.
     *
     * @param inventory   the inventory system for managing products.
     * @param addressBook the address book for managing customer records.
     */
    public Farm(Inventory inventory, AddressBook addressBook) {
        this.inventory = inventory;
        this.addressBook = addressBook;
        this.transactionManager = new TransactionManager();
        this.transactionHistory = new TransactionHistory();
    }

    /**
     * Retrieves a list of all customers stored in the address book.
     *
     * @return a list of all customers.
     */
    public List<Customer> getAllCustomers() {
        return addressBook.getAllRecords();
    }

    /**
     * Retrieves a list of all products available in the inventory.
     *
     * @return a list of all products in stock.
     */
    public List<Product> getAllStock() {
        return inventory.getAllProducts();
    }

    /**
     * Gets the transaction manager for handling ongoing transactions.
     *
     * @return the transaction manager.
     */
    public TransactionManager getTransactionManager() {
        return transactionManager;
    }

    /**
     * Gets the transaction history, which tracks all completed transactions.
     *
     * @return the transaction history.
     */
    public TransactionHistory getTransactionHistory() {
        return transactionHistory;
    }

    /**
     * Saves a customer to the address book.
     *
     * @param customer the customer to be saved.
     * @throws DuplicateCustomerException if a customer with the same name and phone number already exists.
     */
    public void saveCustomer(Customer customer) throws DuplicateCustomerException {
        addressBook.addCustomer(customer);
    }

    /**
     * Stocks a product in the inventory with a given barcode and quality.
     *
     * @param barcode the barcode of the product.
     * @param quality the quality of the product.
     */
    public void stockProduct(Barcode barcode, Quality quality) {
        inventory.addProduct(barcode, quality);
    }

    /**
     * Stocks multiple products in the inventory with a given barcode and quality.
     *
     * @param barcode  the barcode of the product.
     * @param quality  the quality of the product.
     * @param quantity the number of products to stock.
     * @throws InvalidStockRequestException if the inventory cannot handle multiple product additions.
     */
    public void stockProduct(Barcode barcode, Quality quality, int quantity)
            throws InvalidStockRequestException {
        if (quantity < 1) {
            throw new IllegalArgumentException("Quantity must be at least 1.");
        }
        inventory.addProduct(barcode, quality, quantity);
    }

    /**
     * Starts a transaction for a given customer.
     *
     * @param transaction the transaction to start.
     * @throws FailedTransactionException if the customer does not exist in the address book.
     */
    public void startTransaction(Transaction transaction) throws FailedTransactionException {
        if (!addressBook.containsCustomer(transaction.getAssociatedCustomer())) {
            throw new FailedTransactionException("Customer does not exist in the address book.");
        }
        transactionManager.setOngoingTransaction(transaction);
    }

    /**
     * Adds a single product to the ongoing transaction's cart.
     *
     * @param barcode the barcode of the product to add.
     * @return 1 if the product was successfully added, 0 if not.
     * @throws FailedTransactionException if there is no ongoing transaction.
     */
    public int addToCart(Barcode barcode) throws FailedTransactionException {
        if (!transactionManager.hasOngoingTransaction()) {
            throw new FailedTransactionException("Cannot add to cart when "
                    + "no customer has started shopping.");
        }
        List<Product> products = inventory.removeProduct(barcode);
        if (!products.isEmpty()) {
            transactionManager.registerPendingPurchase(products.get(0));
            return 1;
        }
        return 0;
    }

    /**
     * Adds multiple products to the ongoing transaction's cart.
     *
     * @param barcode  the barcode of the products to add.
     * @param quantity the number of products to add.
     * @return the number of products successfully added to the cart.
     * @throws FailedTransactionException if there is no ongoing transaction.
     */
    public int addToCart(Barcode barcode, int quantity) throws FailedTransactionException {
        if (!transactionManager.hasOngoingTransaction()) {
            throw new FailedTransactionException("Cannot add to "
                    + "cart when no customer has started shopping.");
        }
        if (quantity < 1) {
            throw new IllegalArgumentException("Quantity must be at least 1.");
        }

        List<Product> products = inventory.removeProduct(barcode, quantity);
        for (Product product : products) {
            transactionManager.registerPendingPurchase(product);
        }
        return products.size();
    }

    /**
     * Finalizes the ongoing transaction and records it in the transaction history if it contains products.
     *
     * @return true if the transaction had products and was successfully recorded, false otherwise.
     * @throws FailedTransactionException if there is no ongoing transaction.
     */
    public boolean checkout() throws FailedTransactionException {
        if (!transactionManager.hasOngoingTransaction()) {
            throw new FailedTransactionException("No ongoing transaction to checkout.");
        }
        Transaction transaction = transactionManager.closeCurrentTransaction();
        boolean hasProducts = !transaction.getPurchases().isEmpty();
        if (hasProducts) {
            transactionHistory.recordTransaction(transaction);
        }
        return hasProducts;
    }

    /**
     * Retrieves the receipt for the last completed transaction.
     *
     * @return the receipt of the last transaction, or null if there is no transaction history.
     */
    public String getLastReceipt() {
        Transaction lastTransaction = transactionHistory.getLastTransaction();
        return lastTransaction != null ? lastTransaction.getReceipt() : null;
    }

    /**
     * Retrieves a customer from the address book based on their name and phone number.
     *
     * @param name        the name of the customer.
     * @param phoneNumber the phone number of the customer.
     * @return the customer matching the provided name and phone number.
     * @throws CustomerNotFoundException if no matching customer is found.
     */
    public Customer getCustomer(String name, int phoneNumber) throws CustomerNotFoundException {
        return addressBook.getCustomer(name, phoneNumber);
    }
}
