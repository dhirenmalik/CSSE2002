package farm.core;

import java.io.Serializable;

/**
 * Thrown if a customer is not found when looked up.
 * This exception is a component of Stage 1.
 */
public class CustomerNotFoundException extends Exception implements Serializable {

    /**
     * Constructs a new {@code CustomerNotFoundException} without any additional details.
     */
    public CustomerNotFoundException() {
        super();
    }

    /**
     * Constructs a new {@code CustomerNotFoundException} with a message describing the exception.
     *
     * @param message The description of the exception.
     */
    public CustomerNotFoundException(String message) {
        super(message);
    }
}
