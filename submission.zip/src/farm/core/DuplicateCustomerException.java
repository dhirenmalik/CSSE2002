package farm.core;

import java.io.Serializable;

/**
 * Thrown when attempting to add a customer that already exists with the same details.
 * This exception is a component of Stage 1.
 */
public class DuplicateCustomerException extends Exception implements Serializable {

    /**
     * Constructs a new {@code DuplicateCustomerException} without any additional details.
     */
    public DuplicateCustomerException() {
        super();
    }

    /**
     * Constructs a new {@code DuplicateCustomerException} with a message describing the exception.
     *
     * @param message The description of the exception.
     */
    public DuplicateCustomerException(String message) {
        super(message);
    }
}
