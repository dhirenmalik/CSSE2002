package farm.core;

import java.io.Serializable;

/**
 * Thrown if a transaction failed.
 * Component of Stage 2.
 */
public class FailedTransactionException extends Exception implements Serializable {

    /**
     * Construct a failed transaction exception without any additional details.
     */
    public FailedTransactionException() {
        super();
    }

    /**
     * Construct a failed transaction exception with a message describing the exception.
     *
     * @param message The description of the exception.
     */
    public FailedTransactionException(String message) {
        super(message);
    }
}