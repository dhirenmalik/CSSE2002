package farm.customer;

import farm.sales.Cart;

import java.util.Objects;

/**
 * A customer who interacts with the farmer's business.
 * <p>
 * Keeps a record of the customer's information.
 * </p>
 * <p>
 * Component of Stage 0 and Stage 1.
 * </p>
 */
public class Customer {

    private String name;
    private int phoneNumber;
    private String address;
    private Cart cart;

    /**
     * Creates a new customer instance with their details.
     * <p>
     * Requires that the name and address are non-empty, and the phone number is a positive number.
     * </p>
     *
     * @param name The name of the customer.
     * @param phoneNumber The customer's phone number.
     * @param address The address of the customer.
     */
    public Customer(String name, int phoneNumber, String address) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.cart = new Cart();
    }

    /**
     * Determines whether the provided object is equal to this customer instance.
     * <p>
     * For customers, equality is defined by having the same phone number and name; addresses are
     * not considered.
     * Note that customer names are case-sensitive.
     * </p>
     *
     * @param obj The object to compare with.
     * @return {@code true} if the object is a customer with the same phone number and name as this
     * customer; {@code false} otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        // Check if the object is being compared with itself
        if (this == obj) {
            return true;
        }

        // Check if obj is null or not an instance of Customer
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        // Cast obj to Customer
        Customer other = (Customer) obj;

        // Compare phone numbers and names (case-sensitive)
        return this.phoneNumber == other.phoneNumber
                && this.name.equals(other.name);
    }

    /**
     * Retrieves the name of the customer.
     *
     * @return The customer's name.
     */
    public String getName() {
        return name;
    }

    /**
     * Retrieves the customer's cart.
     *
     * @return The customer's shopping cart.
     */
    public Cart getCart() {
        return this.cart;
    }

    /**
     * Updates the current name of the customer with a new one.
     * <p>
     * Requires that the new name is non-empty and has no trailing whitespaces.
     * </p>
     *
     * @param newName The new name to override the current name.
     * @throws IllegalArgumentException If the new name is empty.
     */
    public void setName(String newName) {
        if (newName == null || newName.trim().isEmpty()) {
            throw new IllegalArgumentException("Name cannot be empty");
        }
        this.name = newName.trim();
    }

    /**
     * Retrieves the phone number of the customer.
     *
     * @return The customer's phone number.
     */
    public int getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * Sets the current phone number of the customer.
     * <p>
     * Requires that the new phone number is positive.
     * </p>
     *
     * @param newPhone The phone number to override the current phone number.
     * @throws IllegalArgumentException If the new phone number is not positive.
     */
    public void setPhoneNumber(int newPhone) {
        if (newPhone <= 0) {
            throw new IllegalArgumentException("Phone number must be a positive number");
        }
        this.phoneNumber = newPhone;
    }

    /**
     * Retrieves the address of the customer.
     *
     * @return The customer's address.
     */
    public String getAddress() {
        return address;
    }

    /**
     * Sets the current address of the customer.
     * <p>
     * Requires that the new address is non-empty and has no trailing whitespaces.
     * </p>
     *
     * @param newAddress The address to override the current address.
     * @throws IllegalArgumentException If the new address is empty.
     */
    public void setAddress(String newAddress) {
        if (newAddress == null || newAddress.trim().isEmpty()) {
            throw new IllegalArgumentException("Address cannot be empty");
        }
        this.address = newAddress.trim();
    }

    /**
     * A hash code method that respects the {@link #equals(Object)} method.
     *
     * @return An appropriate hash code value for this instance.
     */
    @Override
    public int hashCode() {
        return Objects.hash(name, phoneNumber);
    }

    /**
     * Returns a string representation of this customer.
     * <p>
     * The representation contains the name of the customer, followed by their phone number and
     * address separated by ' | '.
     * </p>
     *
     * @return The formatted string representation of the customer.
     */
    @Override
    public String toString() {
        return "Name: " + name + " | Phone Number: " + phoneNumber + " | Address: " + address;
    }
}
