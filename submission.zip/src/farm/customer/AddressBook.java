package farm.customer;

import farm.core.CustomerNotFoundException;
import farm.core.DuplicateCustomerException;

import java.util.ArrayList;
import java.util.List;

/**
 * The address book where the farmer stores their customers' details.
 * <p>
 * Keeps track of all the customers that come and visit the Farm.
 * <p>
 * Component of Stage 0 and Stage 1.
 */
public class AddressBook {

    private List<Customer> customers;

    /**
     * Constructs a new instance of {@code AddressBook}.
     * <p>
     * Initializes the address book with an empty list of customers.
     * </p>
     */
    public AddressBook() {
        customers = new ArrayList<>();
    }

    /**
     * Adds a new customer to the address book.
     * <p>
     * If the address book already contains the customer, throws a {@link DuplicateCustomerException}
     * with a message indicating the duplicate customer.
     * </p>
     *
     * @param customer The customer to be added.
     * @throws DuplicateCustomerException If the customer already exists in the address book.
     */
    public void addCustomer(Customer customer) throws DuplicateCustomerException {
        for (Customer existingCustomer : customers) {
            if (existingCustomer.getName().equals(customer.getName())
                    &&
                existingCustomer.getPhoneNumber() == customer.getPhoneNumber()) {
                throw new DuplicateCustomerException("Customer already exists: "
                        + customer.getName());
            }
        }
        this.customers.add(customer);
    }

    /**
     * Checks if a customer is already in the address book.
     *
     * @param customer The customer to check.
     * @return {@code true} if the customer exists in the address book; {@code false} otherwise.
     */
    public boolean containsCustomer(Customer customer) {
        return customers.contains(customer);
    }

    /**
     * Retrieves all customer records stored in the address book.
     * <p>
     * The returned list is a shallow copy and cannot modify the original address book.
     * </p>
     *
     * @return A list of all customers in the address book.
     */
    public List<Customer> getAllRecords() {
        return new ArrayList<>(customers);
    }

    /**
     * Looks up a customer in the address book using their details.
     * <p>
     * If the customer does not exist, throws a {@link CustomerNotFoundException}.
     * </p>
     *
     * @param name The name of the customer to look up.
     * @param phoneNumber The phone number of the customer.
     * @return The customer if found.
     * @throws CustomerNotFoundException If the customer is not found in the address book.
     */
    public Customer getCustomer(String name, int phoneNumber) throws CustomerNotFoundException {
        for (Customer customer : customers) {
            if (customer.getName().equals(name) && customer.getPhoneNumber() == phoneNumber) {
                return customer;
            }
        }
        throw new CustomerNotFoundException("Customer not found with name: " + name
                + " and phone number: " + phoneNumber);
    }
}
