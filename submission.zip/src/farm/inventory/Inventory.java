package farm.inventory;

import farm.inventory.product.data.Barcode;
import farm.inventory.product.data.Quality;
import farm.inventory.product.Product;
import farm.core.InvalidStockRequestException;
import farm.core.FailedTransactionException;

import java.util.List;

/**
 * Represents an inventory system for managing products.
 * This interface provides methods to add, remove, and check the existence of products.
 */
public interface Inventory {

    /**
     * Adds a single product to the inventory with the specified barcode and quality.
     *
     * @param barcode the barcode identifying the product.
     * @param quality the quality of the product being added.
     */
    void addProduct(Barcode barcode, Quality quality);

    /**
     * Adds a specified quantity of products to the inventory.
     *
     * @param barcode  the barcode identifying the product.
     * @param quality  the quality of the products being added.
     * @param quantity the number of products to add.
     * @throws InvalidStockRequestException if the quantity is invalid for this inventory type.
     */
    void addProduct(Barcode barcode, Quality quality, int quantity) throws
            InvalidStockRequestException;

    /**
     * Checks if a product with the given barcode exists in the inventory.
     *
     * @param barcode the barcode identifying the product.
     * @return true if the product exists, false otherwise.
     */
    boolean existsProduct(Barcode barcode);

    /**
     * Retrieves a list of all products currently in the inventory.
     *
     * @return a list of all products in the inventory.
     */
    List<Product> getAllProducts();

    /**
     * Removes a single product from the inventory based on its barcode.
     *
     * @param barcode the barcode identifying the product to remove.
     * @return a list containing the removed product, or an empty list if the product was not found.
     */
    List<Product> removeProduct(Barcode barcode);

    /**
     * Removes a specified quantity of products from the inventory based on their barcode.
     *
     * @param barcode  the barcode identifying the products to remove.
     * @param quantity the number of products to remove.
     * @return a list of the removed products.
     * @throws FailedTransactionException if the transaction fails, such as if there is insufficient stock.
     */
    List<Product> removeProduct(Barcode barcode, int quantity) throws FailedTransactionException;
}
