package farm.inventory;

import farm.inventory.product.Product;
import farm.inventory.product.data.Barcode;
import farm.inventory.product.data.Quality;
import farm.core.InvalidStockRequestException;
import farm.core.FailedTransactionException;

import java.util.ArrayList;
import java.util.List;

/**
 * The BasicInventory class provides a simple implementation of an inventory system.
 * It allows adding, checking, and removing products based on their barcode and quality.
 */
public class BasicInventory implements Inventory {
    private List<Product> products;

    /**
     * Constructs a BasicInventory with an empty list of products.
     */
    public BasicInventory() {
        this.products = new ArrayList<>();
    }

    /**
     * Adds a single product to the inventory based on its barcode and quality.
     *
     * @param barcode the barcode of the product.
     * @param quality the quality of the product.
     */
    @Override
    public void addProduct(Barcode barcode, Quality quality) {
        products.add(new ConcreteProduct(barcode, quality));
    }

    /**
     * Attempts to add multiple products to the inventory, but this is not supported by
     * BasicInventory.
     *
     * @param barcode  the barcode of the product.
     * @param quality  the quality of the product.
     * @param quantity the number of products to add.
     * @throws InvalidStockRequestException if multiple products are added.
     */
    @Override
    public void addProduct(Barcode barcode, Quality quality, int quantity)
            throws InvalidStockRequestException {
        throw new InvalidStockRequestException("Current inventory is not fancy enough. "
                + "Please supply products one at a time.");
    }

    /**
     * Checks if a product with the given barcode exists in the inventory.
     *
     * @param barcode the barcode of the product to check.
     * @return true if a product with the barcode exists, false otherwise.
     */
    @Override
    public boolean existsProduct(Barcode barcode) {
        return products.stream().anyMatch(product -> product.getBarcode().equals(barcode));
    }

    /**
     * Removes a single product with the specified barcode from the inventory.
     *
     * @param barcode the barcode of the product to remove.
     * @return a list containing the removed product, or an empty list if the product was not found.
     */
    @Override
    public List<Product> removeProduct(Barcode barcode) {
        List<Product> removedProducts = new ArrayList<>();
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getBarcode().equals(barcode)) {
                removedProducts.add(products.remove(i));
                break;
            }
        }
        return removedProducts.isEmpty() ? new ArrayList<>() : removedProducts;
    }

    /**
     * Attempts to remove multiple products with the specified barcode, but this is not supported by BasicInventory.
     *
     * @param barcode  the barcode of the product to remove.
     * @param quantity the number of products to remove.
     * @throws FailedTransactionException if multiple products are removed.
     */
    @Override
    public List<Product> removeProduct(Barcode barcode, int quantity) throws
            FailedTransactionException {
        throw new FailedTransactionException("Current inventory is not fancy enough."
                + "Please purchase products one at a time.");
    }

    /**
     * Retrieves all products currently in the inventory.
     *
     * @return a list of all products in the inventory.
     */
    @Override
    public List<Product> getAllProducts() {
        return new ArrayList<>(products);
    }

    /**
     * Inner class to create concrete Product instances.
     */
    private static class ConcreteProduct extends Product {
        public ConcreteProduct(Barcode barcode, Quality quality) {
            super(barcode, quality);
        }
    }
}
