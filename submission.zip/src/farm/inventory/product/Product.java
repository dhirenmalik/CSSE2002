package farm.inventory.product;

import farm.inventory.product.data.Barcode;
import farm.inventory.product.data.Quality;
import java.util.Objects;

/**
 * An abstract class representing an instance of a product.
 * <p>
 * Each product is a single instance of a specific item, identified by a barcode and quality.
 * </p>
 * <p>
 * Component of Stage 1.
 * </p>
 */
public abstract class Product {

    private final Barcode barcode;
    private final Quality quality;

    /**
     * Constructs a Product with the specified barcode and quality.
     *
     * @param barcode the barcode identifying this product.
     * @param quality the quality level of this product.
     */
    protected Product(Barcode barcode, Quality quality) {
        this.barcode = barcode;
        this.quality = quality;
    }

    /**
     * Accessor method for the product's identifier.
     *
     * @return the identifying Barcode for this product.
     */
    public Barcode getBarcode() {
        return barcode;
    }

    /**
     * Retrieve the product's display name for visual/textual representation.
     *
     * @return the product's display name.
     */
    public String getDisplayName() {
        return barcode.getDisplayName();
    }

    /**
     * Retrieve the product's quality.
     *
     * @return the quality level for this product.
     */
    public Quality getQuality() {
        return quality;
    }

    /**
     * Retrieve the product's base sale price.
     *
     * @return the price of the product, in cents.
     */
    public int getBasePrice() {
        return barcode.getBasePrice();
    }

    /**
     * Returns a string representation of this product.
     * <p>
     * The representation contains the display name of the product, followed by its base price and
     * quality.
     * The format is &lt;name&gt;:&lt;price&gt;c *&lt;quality&gt;*.
     * </p>
     * <p>
     * Example output: "bread: 240c *IRIDIUM*"
     * </p>
     *
     * @return the formatted string representation of the product.
     */
    @Override
    public String toString() {
        return String.format("%s: %dc *%s*", getDisplayName(), getBasePrice(), quality);
    }

    /**
     * Determines whether the provided object is equal to this product instance.
     * <p>
     * Equality is defined by having the same barcode and quality.
     * </p>
     *
     * @param obj the object to compare with.
     * @return true if the other object is a product with the same barcode and quality as this
     * product.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Product product = (Product) obj;
        return barcode == product.barcode && quality == product.quality;
    }

    /**
     * Returns a hash code value for this product.
     * <p>
     * The hash code respects the equals method and is based on the product's barcode and quality.
     * </p>
     *
     * @return an appropriate hash code value for this instance.
     */
    @Override
    public int hashCode() {
        return Objects.hash(barcode, quality);
    }
}
