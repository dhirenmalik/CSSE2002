package farm.inventory.product;

import farm.inventory.product.data.Barcode;
import farm.inventory.product.data.Quality;

/**
 * A class representing an instance of an egg.
 * <p>
 * Note: Refer to the `Barcode` class for product information such as price and name,
 * specifically `Barcode.EGG`.
 * </p>
 * <p>
 * Component of Stage 1.
 * </p>
 */
public class Egg extends Product {

    /**
     * Create an egg instance with no additional details.
     * <p>
     * The item quality is not specified, so it will default to REGULAR.
     * </p>
     */
    public Egg() {
        this(Quality.REGULAR);
    }

    /**
     * Create an egg instance with a quality value.
     *
     * @param quality the quality level to assign to this egg.
     */
    public Egg(Quality quality) {
        super(Barcode.EGG, quality);
    }
}
