package farm.inventory.product;

import farm.inventory.product.data.Barcode;
import farm.inventory.product.data.Quality;

/**
 * A class representing an instance of jam.
 * <p>
 * Note: Refer to the `Barcode` class for product information such as price and name,
 * specifically `Barcode.JAM`.
 * </p>
 * <p>
 * Component of Stage 1.
 * </p>
 */
public class Jam extends Product {

    /**
     * Create a jam instance with no additional details.
     * <p>
     * The item quality is not specified, so it will default to REGULAR.
     * </p>
     */
    public Jam() {
        this(Quality.REGULAR);
    }

    /**
     * Create a jam instance with a quality value.
     *
     * @param quality the quality level to assign to this jam.
     */
    public Jam(Quality quality) {
        super(Barcode.JAM, quality);
    }
}
