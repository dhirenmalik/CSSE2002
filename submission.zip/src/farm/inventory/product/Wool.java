package farm.inventory.product;

import farm.inventory.product.data.Barcode;
import farm.inventory.product.data.Quality;

/**
 * A class representing an instance of wool.
 * <p>
 * Note: See {@code Barcode.WOOL} for product information such as price and name.
 * </p>
 * <p>
 * Component of Stage 1.
 * </p>
 */
public class Wool extends Product {

    /**
     * Creates a wool instance with no additional details.
     * <p>
     * The item quality is not specified, so it will default to {@code Quality.REGULAR}.
     * </p>
     */
    public Wool() {
        this(Quality.REGULAR);
    }

    /**
     * Creates a wool instance with a specific quality value.
     *
     * @param quality the quality level to assign to this wool.
     */
    public Wool(Quality quality) {
        super(Barcode.WOOL, quality);
    }
}
